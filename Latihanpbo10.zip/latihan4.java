import java.awt.Button;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import javax.swing.*;

/**
 *
 * @author Henry Lianto
 */
public class latihan4 extends JFrame{
    public static void main(String[] args){
        latihan4 a = new latihan4();
    }
public latihan4(){
    GridBagLayout grid = new GridBagLayout();
        GridBagConstraints gbc = new GridBagConstraints();
        setLayout(grid);
        setTitle("GridBagLayout Example");
        GridBagLayout layout = new GridBagLayout();
       this.setLayout(layout);
       gbc.fill = GridBagConstraints.HORIZONTAL;
       gbc.gridx=0;
       gbc.gridy=0;
       this.add(new Button("button one"),gbc);
       gbc.gridx=1;
       gbc.gridy=0;
       this.add(new Button("button two"),gbc);
       gbc.fill=GridBagConstraints.HORIZONTAL;
       gbc.ipady=20;
       gbc.gridx=0;
       gbc.gridy=1;
       this.add(new Button("button three"),gbc);
       gbc.gridx=5;
       gbc.gridy=1;
       this.add(new Button("button four"),gbc);
       gbc.gridx=3;
       gbc.gridy=2;
       gbc.fill=GridBagConstraints.HORIZONTAL;
       gbc.gridwidth=2;
       this.add(new Button("button five"),gbc);
            setSize(300,300);
            setPreferredSize(getSize());
            setVisible(true);
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            
       
          
}
}



import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.Container;
import java.awt.FlowLayout;
/**
 *
 * @author Henry Lianto
 */
public class latihan2 extends JFrame {
    
    public latihan2(){
        FlowLayout latihan2 = new FlowLayout(FlowLayout.CENTER,5,10);
        
        Container container = getContentPane();
        
        container.setLayout(latihan2);
        
        container.add(new JButton("tombol 1"));
        container.add(new JButton("tombol 2"));
        container.add(new JButton("tombol 3"));
        container.add(new JButton("tombol 4"));
        container.add(new JButton("tombol 5"));
        
    }
    public static void main(String[] args) {
        latihan2 jendela = new latihan2();
      jendela.setTitle("Kelas DemoFlowLayout");
      jendela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      jendela.setSize(180,300);
      jendela.setVisible(true);
    }
}

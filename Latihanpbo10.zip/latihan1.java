

import java.awt.BorderLayout;
import java.awt.Frame;
import javax.swing.*;

/**
 *
 * @author Henry Lianto
 */
public class latihan1 extends JFrame {
    
    JButton nButton = new JButton("North");
    JButton sButton = new JButton("South");
    JButton wButton = new JButton("West");
    JButton eButton = new JButton("East");
    JButton cButton = new JButton("Center");

public latihan1() {
    super("Border Layout Beraksi");
    setSize(300,280);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setLayout(new BorderLayout());
       add(nButton, BorderLayout.NORTH);
       add(sButton, BorderLayout.SOUTH);
       add(wButton, BorderLayout.WEST);
       add(eButton, BorderLayout.EAST);
       add(cButton, BorderLayout.CENTER);}
        
  public static void main(String[] args){
          latihan1 frame= new latihan1();
          frame.setVisible(true);
          
       }

}